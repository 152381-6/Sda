import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { fetchProducts, filterProducts } from '../store/slices/productSlice';
import { addToCart } from '../store/slices/cartSlice';
import { addNotification } from '../store/slices/uiSlice';

const ShopPage = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  
  const { products, filteredProducts, loading, error } = useSelector((state) => state.products);
  
  // State for filters
  const [filters, setFilters] = useState({
    category: '',
    minPrice: '',
    maxPrice: '',
    rating: '',
    sort: 'popularity',
    search: '',
  });
  
  // Get URL params
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const categoryParam = searchParams.get('category');
    const searchParam = searchParams.get('search');
    const saleParam = searchParams.get('sale');
    
    if (categoryParam) {
      setFilters(prev => ({ ...prev, category: categoryParam }));
    }
    
    if (searchParam) {
      setFilters(prev => ({ ...prev, search: searchParam }));
    }
    
    if (saleParam === 'true') {
      // Mock implementation for sale items - in a real app this would be different
      setFilters(prev => ({ ...prev, onSale: true }));
    }
  }, [location.search]);
  
  // Fetch products on component mount
  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);
  
  // Apply filters when filter state changes
  useEffect(() => {
    dispatch(filterProducts(filters));
    
    // Update URL with filter parameters
    const searchParams = new URLSearchParams();
    
    if (filters.category) searchParams.set('category', filters.category);
    if (filters.search) searchParams.set('search', filters.search);
    if (filters.minPrice) searchParams.set('min_price', filters.minPrice);
    if (filters.maxPrice) searchParams.set('max_price', filters.maxPrice);
    if (filters.rating) searchParams.set('rating', filters.rating);
    if (filters.sort) searchParams.set('sort', filters.sort);
    
    const searchString = searchParams.toString();
    navigate({ search: searchString ? `?${searchString}` : '' }, { replace: true });
    
  }, [filters, dispatch, navigate]);
  
  const handleAddToCart = (product) => {
    dispatch(addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
    }));
    
    dispatch(addNotification({
      type: 'success',
      message: `${product.name} added to your cart`,
    }));
  };
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prevFilters => ({
      ...prevFilters,
      [name]: value,
    }));
  };
  
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const searchQuery = formData.get('searchQuery');
    
    setFilters(prevFilters => ({
      ...prevFilters,
      search: searchQuery,
    }));
  };
  
  const handleClearFilters = () => {
    setFilters({
      category: '',
      minPrice: '',
      maxPrice: '',
      rating: '',
      sort: 'popularity',
      search: '',
    });
  };
  
  // Get all available categories from products
  const categories = [...new Set(products?.map(product => product.category) || [])];
  
  // Mock categories if none available from products
  const mockCategories = [
    'Electronics',
    'Fashion',
    'Home & Living',
    'Health & Beauty',
    'Sports',
    'Toys & Games',
    'Books',
    'Automotive',
  ];
  
  const displayCategories = categories.length > 0 ? categories : mockCategories;
  
  // Display products or loading/error states
  const renderProducts = () => {
    if (loading) {
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 animate-pulse">
              <div className="w-full h-48 bg-gray-300 dark:bg-gray-700 rounded-md mb-4"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded mb-2"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-2/3 mb-4"></div>
              <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded"></div>
            </div>
          ))}
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="text-center py-8">
          <p className="text-red-500 dark:text-red-400">Error: {error}</p>
          <button
            onClick={() => dispatch(fetchProducts())}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Try Again
          </button>
        </div>
      );
    }
    
    const productsToShow = filteredProducts.length > 0 ? filteredProducts : products;
    
    if (productsToShow.length === 0) {
      return (
        <div className="text-center py-12">
          <svg className="mx-auto h-16 w-16 text-gray-400 dark:text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="mt-4 text-lg font-medium text-gray-900 dark:text-white">No products found</h3>
          <p className="mt-1 text-gray-500 dark:text-gray-400">Try adjusting your search or filter criteria.</p>
          <button
            onClick={handleClearFilters}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Clear All Filters
          </button>
        </div>
      );
    }
    
    // Mock products if none are available
    const mockProducts = [
      {
        id: '1',
        name: 'Wireless Earbuds',
        category: 'Electronics',
        description: 'High-quality wireless earbuds with noise cancellation',
        price: 89.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Earbuds',
        rating: 4.5,
      },
      {
        id: '2',
        name: 'Smart Watch',
        category: 'Electronics',
        description: 'Fitness tracking with heart rate monitoring',
        price: 199.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Watch',
        rating: 4.8,
      },
      {
        id: '3',
        name: 'Laptop Backpack',
        category: 'Fashion',
        description: 'Water-resistant laptop backpack with USB charging port',
        price: 49.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Backpack',
        rating: 4.2,
      },
      {
        id: '4',
        name: 'Bluetooth Speaker',
        category: 'Electronics',
        description: 'Portable bluetooth speaker with 20-hour battery life',
        price: 79.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Speaker',
        rating: 4.7,
      },
      {
        id: '5',
        name: 'Yoga Mat',
        category: 'Sports',
        description: 'Non-slip yoga mat with carrying strap',
        price: 29.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Yoga+Mat',
        rating: 4.3,
      },
      {
        id: '6',
        name: 'Coffee Maker',
        category: 'Home & Living',
        description: 'Programmable coffee maker with thermal carafe',
        price: 119.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Coffee+Maker',
        rating: 4.6,
      },
      {
        id: '7',
        name: 'Wireless Keyboard',
        category: 'Electronics',
        description: 'Ergonomic wireless keyboard with customizable keys',
        price: 59.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Keyboard',
        rating: 4.4,
      },
      {
        id: '8',
        name: 'Skincare Set',
        category: 'Health & Beauty',
        description: 'Complete skincare routine with cleanser, toner, and moisturizer',
        price: 39.99,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Skincare',
        rating: 4.9,
      },
    ];
    
    const displayProducts = productsToShow.length > 0 ? productsToShow : mockProducts;
    
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {displayProducts.map((product) => (
          <div key={product.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-transform hover:-translate-y-1 hover:shadow-lg">
            <div 
              className="h-48 overflow-hidden cursor-pointer"
              onClick={() => navigate(`/product/${product.id}`)}
            >
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-4">
              <div 
                className="cursor-pointer"
                onClick={() => navigate(`/product/${product.id}`)}
              >
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">{product.name}</h3>
                <div className="flex items-center mb-2">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <svg 
                        key={i} 
                        className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'}`}
                        fill="currentColor" 
                        viewBox="0 0 20 20"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  <span className="text-gray-500 dark:text-gray-400 text-sm ml-1">({product.rating})</span>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2 line-clamp-2">{product.description}</p>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-xl font-bold text-gray-900 dark:text-white">${product.price.toFixed(2)}</p>
                <button
                  onClick={() => handleAddToCart(product)}
                  className="p-2 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                  aria-label="Add to cart"
                >
                  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Filters sidebar */}
        <div className="w-full md:w-64 flex-shrink-0 bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 h-fit">
          <h2 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Filters</h2>
          
          {/* Search */}
          <form onSubmit={handleSearchSubmit} className="mb-6">
            <div className="relative">
              <input
                type="text"
                name="searchQuery"
                placeholder="Search products..."
                value={filters.search}
                onChange={(e) => handleFilterChange({ target: { name: 'search', value: e.target.value } })}
                className="w-full p-2 pr-10 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              />
              <button
                type="submit"
                className="absolute right-0 top-0 mt-2 mr-2 text-gray-400 hover:text-gray-500"
              >
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>
            </div>
          </form>
          
          {/* Category filter */}
          <div className="mb-6">
            <h3 className="text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Category</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <input
                  id="category-all"
                  name="category"
                  type="radio"
                  value=""
                  checked={filters.category === ''}
                  onChange={handleFilterChange}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                />
                <label htmlFor="category-all" className="ml-2 text-sm text-gray-600 dark:text-gray-400">
                  All Categories
                </label>
              </div>
              
              {displayCategories.map((category) => (
                <div key={category} className="flex items-center">
                  <input
                    id={`category-${category}`}
                    name="category"
                    type="radio"
                    value={category}
                    checked={filters.category === category}
                    onChange={handleFilterChange}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                  />
                  <label htmlFor={`category-${category}`} className="ml-2 text-sm text-gray-600 dark:text-gray-400">
                    {category}
                  </label>
                </div>
              ))}
            </div>
          </div>
          
          {/* Price range filter */}
          <div className="mb-6">
            <h3 className="text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Price Range</h3>
            <div className="flex space-x-2">
              <div className="flex-1">
                <label htmlFor="minPrice" className="sr-only">Min Price</label>
                <input
                  id="minPrice"
                  name="minPrice"
                  type="number"
                  placeholder="Min"
                  value={filters.minPrice}
                  onChange={handleFilterChange}
                  className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              <span className="text-gray-500 dark:text-gray-400 self-center">-</span>
              <div className="flex-1">
                <label htmlFor="maxPrice" className="sr-only">Max Price</label>
                <input
                  id="maxPrice"
                  name="maxPrice"
                  type="number"
                  placeholder="Max"
                  value={filters.maxPrice}
                  onChange={handleFilterChange}
                  className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
            </div>
          </div>
          
          {/* Rating filter */}
          <div className="mb-6">
            <h3 className="text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">Rating</h3>
            <div className="space-y-2">
              {[0, 4, 3, 2, 1].map((rating) => (
                <div key={rating} className="flex items-center">
                  <input
                    id={`rating-${rating}`}
                    name="rating"
                    type="radio"
                    value={rating}
                    checked={filters.rating === rating.toString()}
                    onChange={handleFilterChange}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                  />
                  <label htmlFor={`rating-${rating}`} className="ml-2 text-sm text-gray-600 dark:text-gray-400 flex items-center">
                    {rating > 0 ? (
                      <>
                        {[...Array(5)].map((_, i) => (
                          <svg 
                            key={i} 
                            className={`h-4 w-4 ${i < rating ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'}`}
                            fill="currentColor" 
                            viewBox="0 0 20 20"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                        <span className="ml-1">& up</span>
                      </>
                    ) : (
                      'All Ratings'
                    )}
                  </label>
                </div>
              ))}
            </div>
          </div>
          
          {/* Reset filters button */}
          <button
            onClick={handleClearFilters}
            className="w-full p-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded-md hover:bg-gray-300 dark:hover:bg-gray-600"
          >
            Clear Filters
          </button>
        </div>
        
        {/* Main content */}
        <div className="flex-1">
          {/* Results header */}
          <div className="flex flex-col md:flex-row justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 md:mb-0">
              {filters.category ? filters.category : 'All Products'}
              {filters.search && ` - Search: "${filters.search}"`}
            </h1>
            
            <div className="flex items-center">
              <label htmlFor="sort" className="mr-2 text-sm text-gray-600 dark:text-gray-400">Sort by:</label>
              <select
                id="sort"
                name="sort"
                value={filters.sort}
                onChange={handleFilterChange}
                className="p-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              >
                <option value="popularity">Popularity</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
                <option value="rating">Customer Rating</option>
                <option value="newest">Newest Arrivals</option>
              </select>
            </div>
          </div>
          
          {/* Products grid */}
          {renderProducts()}
        </div>
      </div>
    </div>
  );
};

export default ShopPage;