import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../store/slices/cartSlice';
import { addNotification } from '../store/slices/uiSlice';

const ProductDetailPage = () => {
  const { productId } = useParams();
  const dispatch = useDispatch();
  const { products } = useSelector((state) => state.products);
  
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [relatedProducts, setRelatedProducts] = useState([]);
  
  // Fetch product details from Redux store or API
  useEffect(() => {
    // Simulate API request delay
    const timer = setTimeout(() => {
      // In a real app, this would fetch the product from an API endpoint
      // For demo, we'll find it from our Redux store or use a mock
      const foundProduct = products.find(p => p.id === productId);
      
      if (foundProduct) {
        setProduct(foundProduct);
        
        // Find related products (same category)
        const related = products
          .filter(p => p.category === foundProduct.category && p.id !== foundProduct.id)
          .slice(0, 4);
        setRelatedProducts(related);
      } else {
        // Mock product data if not found in Redux store
        const mockProduct = getMockProduct(productId);
        setProduct(mockProduct);
        
        // Mock related products
        setRelatedProducts(getMockRelatedProducts(mockProduct.category, productId));
      }
      
      setLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [productId, products]);
  
  const handleQuantityChange = (value) => {
    const newValue = Math.max(1, value);
    setQuantity(newValue);
  };
  
  const handleAddToCart = () => {
    if (!product) return;
    
    dispatch(addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image || product.images?.[0],
      quantity: quantity,
    }));
    
    dispatch(addNotification({
      type: 'success',
      message: `${product.name} added to your cart`,
    }));
  };
  
  // Mock product data generator
  const getMockProduct = (id) => {
    return {
      id,
      name: 'Premium Wireless Earbuds',
      description: 'High-quality wireless earbuds with noise cancellation and water resistance. Features include touch controls, 8-hour battery life, and comfortable fit for all-day wear. Compatible with iOS and Android devices. Includes charging case and multiple ear tip sizes.',
      price: 89.99,
      category: 'Electronics',
      brand: 'SoundWave',
      rating: 4.5,
      reviewCount: 238,
      stock: 45,
      images: [
        'https://placehold.co/600x600/e2e8f0/1e293b?text=Earbuds+1',
        'https://placehold.co/600x600/e2e8f0/1e293b?text=Earbuds+2',
        'https://placehold.co/600x600/e2e8f0/1e293b?text=Earbuds+3',
        'https://placehold.co/600x600/e2e8f0/1e293b?text=Earbuds+4',
      ],
      features: [
        'Active noise cancellation',
        'Water and sweat resistant (IPX4)',
        'Up to 8 hours of listening time',
        'Touch controls for music and calls',
        'Premium sound quality with deep bass',
      ],
      specifications: {
        'Battery Life': '8 hours (earbuds) + 24 hours (charging case)',
        'Connectivity': 'Bluetooth 5.2',
        'Dimensions': '23mm x 15mm x 17mm',
        'Weight': '5g per earbud',
        'Charging': 'USB-C, Wireless Qi compatible',
      },
    };
  };
  
  // Mock related products generator
  const getMockRelatedProducts = (category, currentId) => {
    const mockRelatedProducts = [
      {
        id: 'rel1',
        name: 'Wireless Over-Ear Headphones',
        price: 149.99,
        rating: 4.7,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Headphones',
        category: 'Electronics',
      },
      {
        id: 'rel2',
        name: 'Bluetooth Speaker',
        price: 79.99,
        rating: 4.3,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Speaker',
        category: 'Electronics',
      },
      {
        id: 'rel3',
        name: 'Wireless Charging Pad',
        price: 34.99,
        rating: 4.5,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Charger',
        category: 'Electronics',
      },
      {
        id: 'rel4',
        name: 'True Wireless Earbuds',
        price: 119.99,
        rating: 4.8,
        image: 'https://placehold.co/300x300/e2e8f0/1e293b?text=Earbuds+Pro',
        category: 'Electronics',
      },
    ];
    
    return mockRelatedProducts.filter(p => p.id !== currentId);
  };
  
  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="animate-pulse">
          <div className="md:flex md:items-start">
            <div className="md:w-1/2">
              <div className="w-full h-96 bg-gray-300 dark:bg-gray-700 rounded-lg"></div>
              <div className="mt-4 grid grid-cols-4 gap-2">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-24 bg-gray-300 dark:bg-gray-700 rounded-md"></div>
                ))}
              </div>
            </div>
            <div className="md:w-1/2 md:pl-8 mt-6 md:mt-0">
              <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded w-3/4 mb-4"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-1/2 mb-6"></div>
              <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded w-1/4 mb-6"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full mb-2"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full mb-2"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-3/4 mb-6"></div>
              <div className="h-10 bg-gray-300 dark:bg-gray-700 rounded mb-6"></div>
              <div className="h-12 bg-gray-300 dark:bg-gray-700 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <svg className="mx-auto h-16 w-16 text-gray-400 dark:text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h2 className="mt-2 text-lg font-medium text-gray-900 dark:text-white">Product not found</h2>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          The product you are looking for might have been removed or is temporarily unavailable.
        </p>
        <div className="mt-6">
          <Link to="/shop" className="text-base font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500">
            Continue Shopping
            <span aria-hidden="true"> &rarr;</span>
          </Link>
        </div>
      </div>
    );
  }
  
  const productImages = product.images || [product.image];
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Breadcrumb */}
      <nav className="flex mb-8 text-sm text-gray-500 dark:text-gray-400">
        <Link to="/" className="hover:text-gray-700 dark:hover:text-gray-300">Home</Link>
        <span className="mx-2">/</span>
        <Link to="/shop" className="hover:text-gray-700 dark:hover:text-gray-300">Shop</Link>
        <span className="mx-2">/</span>
        {product.category && (
          <>
            <Link to={`/shop?category=${encodeURIComponent(product.category)}`} className="hover:text-gray-700 dark:hover:text-gray-300">
              {product.category}
            </Link>
            <span className="mx-2">/</span>
          </>
        )}
        <span className="text-gray-700 dark:text-gray-300">{product.name}</span>
      </nav>
      
      {/* Product */}
      <div className="md:flex md:items-start">
        {/* Product images */}
        <div className="md:w-1/2">
          <div className="w-full h-96 bg-white dark:bg-gray-800 rounded-lg overflow-hidden border dark:border-gray-700">
            <img
              src={productImages[selectedImage] || 'https://placehold.co/600x600/e2e8f0/1e293b?text=No+Image'}
              alt={product.name}
              className="w-full h-full object-contain"
            />
          </div>
          {productImages.length > 1 && (
            <div className="mt-4 grid grid-cols-4 gap-2">
              {productImages.map((image, index) => (
                <button
                  key={index}
                  className={`h-24 border rounded-md overflow-hidden focus:outline-none ${
                    selectedImage === index ? 'ring-2 ring-blue-500' : 'dark:border-gray-700'
                  }`}
                  onClick={() => setSelectedImage(index)}
                >
                  <img src={image} alt={`${product.name} view ${index + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Product details */}
        <div className="md:w-1/2 md:pl-8 mt-6 md:mt-0">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{product.name}</h1>
          
          {product.brand && (
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              Brand: <span className="font-medium">{product.brand}</span>
            </p>
          )}
          
          {/* Rating */}
          <div className="mt-4 flex items-center">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <svg 
                  key={i} 
                  className={`h-5 w-5 ${i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'}`}
                  fill="currentColor" 
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
              {product.rating} ({product.reviewCount || 0} {product.reviewCount === 1 ? 'review' : 'reviews'})
            </span>
          </div>
          
          {/* Price */}
          <p className="mt-4 text-3xl font-bold text-gray-900 dark:text-white">${product.price.toFixed(2)}</p>
          
          {/* Availability */}
          <p className="mt-2 text-sm">
            {product.stock > 0 ? (
              <span className="text-green-600 dark:text-green-400">In stock ({product.stock} available)</span>
            ) : (
              <span className="text-red-600 dark:text-red-400">Out of stock</span>
            )}
          </p>
          
          {/* Description */}
          <div className="mt-6">
            <h3 className="text-sm font-medium text-gray-900 dark:text-white">Description</h3>
            <div className="mt-2 space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <p>{product.description}</p>
            </div>
          </div>
          
          {/* Features */}
          {product.features && product.features.length > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-900 dark:text-white">Highlights</h3>
              <ul className="mt-2 space-y-1 list-disc list-inside text-sm text-gray-600 dark:text-gray-400">
                {product.features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>
            </div>
          )}
          
          {/* Add to cart */}
          {product.stock > 0 && (
            <div className="mt-6">
              <div className="flex space-x-4 items-center mb-4">
                <div className="flex border border-gray-300 dark:border-gray-600 rounded-md">
                  <button
                    type="button"
                    onClick={() => handleQuantityChange(quantity - 1)}
                    className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                    disabled={quantity <= 1}
                  >
                    <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 12H4" />
                    </svg>
                  </button>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                    className="w-16 text-center border-none focus:outline-none dark:bg-gray-700 dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={() => handleQuantityChange(quantity + 1)}
                    className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
                    </svg>
                  </button>
                </div>
                
                <button
                  onClick={handleAddToCart}
                  className="flex-1 bg-blue-600 border border-transparent rounded-md py-3 px-8 flex items-center justify-center text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                  Add to Cart
                </button>
              </div>
              
              <button
                className="w-full bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md py-3 px-8 flex items-center justify-center text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600"
              >
                <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
                Add to Wishlist
              </button>
            </div>
          )}
          
          {/* Specifications */}
          {product.specifications && Object.keys(product.specifications).length > 0 && (
            <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-6">
              <h3 className="text-sm font-medium text-gray-900 dark:text-white">Specifications</h3>
              <div className="mt-4">
                <table className="w-full text-sm text-gray-600 dark:text-gray-400">
                  <tbody>
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <tr key={key} className="border-b border-gray-200 dark:border-gray-700">
                        <td className="py-2 font-medium">{key}</td>
                        <td className="py-2 text-right">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Related products */}
      {relatedProducts.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Related Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {relatedProducts.map((product) => (
              <div key={product.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-transform hover:-translate-y-1 hover:shadow-lg">
                <Link to={`/product/${product.id}`}>
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                </Link>
                <div className="p-4">
                  <Link to={`/product/${product.id}`}>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">{product.name}</h3>
                  </Link>
                  <div className="flex items-center mb-2">
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <svg 
                          key={i} 
                          className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'}`}
                          fill="currentColor" 
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <span className="text-gray-500 dark:text-gray-400 text-sm ml-1">({product.rating})</span>
                  </div>
                  <p className="text-xl font-bold text-gray-900 dark:text-white mb-2">${product.price.toFixed(2)}</p>
                  <button
                    onClick={() => {
                      dispatch(addToCart({
                        id: product.id,
                        name: product.name,
                        price: product.price,
                        image: product.image,
                        quantity: 1,
                      }));
                      dispatch(addNotification({
                        type: 'success',
                        message: `${product.name} added to your cart`,
                      }));
                    }}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center"
                  >
                    <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductDetailPage;