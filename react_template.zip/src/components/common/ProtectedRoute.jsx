import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';

const ProtectedRoute = ({ children, roles = [] }) => {
  const location = useLocation();
  // Get authentication state from Redux store
  // This is a simplified version - in a real app, you'd have proper auth state
  const { isAuthenticated, user } = useSelector((state) => state.auth || { isAuthenticated: false, user: { role: 'guest' } });

  // If not authenticated, redirect to login page
  if (!isAuthenticated) {
    return <Navigate to="/auth/login" state={{ from: location }} replace />;
  }

  // If roles are specified and user role doesn't match, redirect to home
  if (roles.length > 0 && !roles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }

  // If authenticated and role is appropriate, render children
  return children;
};

export default ProtectedRoute;