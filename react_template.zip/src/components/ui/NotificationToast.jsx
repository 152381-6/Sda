import { useEffect } from 'react';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import { removeNotification } from '../../store/slices/uiSlice';

const NotificationToast = ({ notification }) => {
  const dispatch = useDispatch();

  // Auto-remove notification after timeout
  useEffect(() => {
    const timer = setTimeout(() => {
      dispatch(removeNotification(notification.id));
    }, notification.duration || 5000);

    return () => clearTimeout(timer);
  }, [dispatch, notification]);

  // Get color scheme based on notification type
  const getTypeStyles = () => {
    switch (notification.type) {
      case 'success':
        return {
          bgClass: 'bg-green-50 dark:bg-green-900/20',
          borderClass: 'border-green-400 dark:border-green-700',
          iconClass: 'text-green-500 dark:text-green-400',
          iconPath: (
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth="2" 
              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" 
            />
          )
        };
      case 'error':
        return {
          bgClass: 'bg-red-50 dark:bg-red-900/20',
          borderClass: 'border-red-400 dark:border-red-700',
          iconClass: 'text-red-500 dark:text-red-400',
          iconPath: (
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth="2" 
              d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" 
            />
          )
        };
      case 'warning':
        return {
          bgClass: 'bg-yellow-50 dark:bg-yellow-900/20',
          borderClass: 'border-yellow-400 dark:border-yellow-700',
          iconClass: 'text-yellow-500 dark:text-yellow-400',
          iconPath: (
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth="2" 
              d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" 
            />
          )
        };
      case 'info':
      default:
        return {
          bgClass: 'bg-blue-50 dark:bg-blue-900/20',
          borderClass: 'border-blue-400 dark:border-blue-700',
          iconClass: 'text-blue-500 dark:text-blue-400',
          iconPath: (
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth="2" 
              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" 
            />
          )
        };
    }
  };

  const typeStyles = getTypeStyles();

  return (
    <div 
      className={`max-w-md w-full p-4 rounded-lg shadow-lg border ${typeStyles.borderClass} ${typeStyles.bgClass} animate-in slide-in-from-right-full duration-300`}
      role="alert"
    >
      <div className="flex items-start">
        <div className={`flex-shrink-0 ${typeStyles.iconClass}`}>
          <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            {typeStyles.iconPath}
          </svg>
        </div>
        <div className="ml-3 flex-1">
          {notification.title && (
            <h3 className="text-sm font-medium text-gray-800 dark:text-gray-100">
              {notification.title}
            </h3>
          )}
          <div className="text-sm text-gray-700 dark:text-gray-300 mt-1">
            {notification.message}
          </div>
        </div>
        <button
          onClick={() => dispatch(removeNotification(notification.id))}
          className="ml-4 flex-shrink-0 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 focus:outline-none"
        >
          <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>
  );
};

NotificationToast.propTypes = {
  notification: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    type: PropTypes.oneOf(['success', 'error', 'warning', 'info']),
    title: PropTypes.string,
    message: PropTypes.string.isRequired,
    duration: PropTypes.number,
  }).isRequired,
};

export default NotificationToast;