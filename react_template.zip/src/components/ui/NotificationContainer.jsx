import { useSelector } from 'react-redux';
import NotificationToast from './NotificationToast';

const NotificationContainer = () => {
  const { notifications } = useSelector((state) => state.ui);

  if (!notifications.length) return null;

  return (
    <div className="fixed top-4 right-4 z-50 space-y-4 w-full max-w-md">
      {notifications.map((notification) => (
        <NotificationToast key={notification.id} notification={notification} />
      ))}
    </div>
  );
};

export default NotificationContainer;