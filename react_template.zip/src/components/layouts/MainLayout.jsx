import { Outlet } from 'react-router-dom';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setTheme } from '../../store/slices/uiSlice';
import Navbar from '../common/Navbar';
import Footer from '../common/Footer';
import CartSidebar from '../common/CartSidebar';
import NotificationToast from '../ui/NotificationToast';

const MainLayout = () => {
  const dispatch = useDispatch();
  const { isCartOpen, notifications, theme } = useSelector((state) => state.ui);
  
  // Initialize theme from localStorage on component mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('dokan_theme') || 'light';
    dispatch(setTheme(savedTheme));
  }, [dispatch]);

  return (
    <div className={`min-h-screen flex flex-col ${theme === 'dark' ? 'dark bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      <Navbar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <Outlet />
      </main>
      
      <Footer />
      
      {/* Cart Sidebar */}
      <CartSidebar isOpen={isCartOpen} />
      
      {/* Notifications */}
      <div className="fixed bottom-4 right-4 z-50 space-y-2">
        {notifications.map((notification) => (
          <NotificationToast
            key={notification.id}
            notification={notification}
          />
        ))}
      </div>
    </div>
  );
};

export default MainLayout;