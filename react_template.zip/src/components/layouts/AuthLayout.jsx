import { Outlet, Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import logo from '/images/logo.jpg';

const AuthLayout = () => {
  const { theme } = useSelector((state) => state.ui);
  
  return (
    <div className={`min-h-screen flex flex-col ${theme === 'dark' ? 'dark bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      <div className="flex justify-center items-center py-4 border-b dark:border-gray-700">
        <Link to="/" className="flex items-center gap-2">
          {/* Use a default placeholder logo if the import fails */}
          <div className="h-10 w-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
            D
          </div>
          <span className="text-xl font-bold">Dokan</span>
        </Link>
      </div>
      
      <div className="flex-grow flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
            <Outlet />
          </div>
        </div>
      </div>
      
      <footer className="py-4 text-center text-sm text-gray-600 dark:text-gray-400">
        <p>© {new Date().getFullYear()} Dokan. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default AuthLayout;