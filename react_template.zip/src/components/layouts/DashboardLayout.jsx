import { Outlet } from 'react-router-dom';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import Sidebar from '../common/Sidebar';
import DashboardHeader from '../common/DashboardHeader';
import NotificationToast from '../ui/NotificationToast';

const DashboardLayout = ({ userType }) => {
  const { isSidebarOpen, notifications } = useSelector((state) => state.ui);
  const { user } = useSelector((state) => state.auth);

  // Define menu items based on user type
  const getSidebarItems = () => {
    switch (userType) {
      case 'seller':
        return [
          { title: 'Dashboard', icon: 'HomeIcon', path: '/seller' },
          { title: 'Products', icon: 'ShoppingBagIcon', path: '/seller/products' },
          { title: 'Orders', icon: 'ShoppingCartIcon', path: '/seller/orders' },
          { title: 'Inventory', icon: 'ArchiveBoxIcon', path: '/seller/inventory' },
          { title: 'Reports', icon: 'ChartBarIcon', path: '/seller/reports' },
          { title: 'Settings', icon: 'CogIcon', path: '/seller/settings' },
        ];
      case 'delivery':
        return [
          { title: 'Dashboard', icon: 'HomeIcon', path: '/delivery' },
          { title: 'Orders', icon: 'TruckIcon', path: '/delivery/orders' },
          { title: 'Tracking', icon: 'MapIcon', path: '/delivery/tracking' },
          { title: 'Finance', icon: 'BanknotesIcon', path: '/delivery/finance' },
          { title: 'Settings', icon: 'CogIcon', path: '/delivery/settings' },
        ];
      case 'admin':
        return [
          { title: 'Dashboard', icon: 'HomeIcon', path: '/admin' },
          { title: 'Users', icon: 'UsersIcon', path: '/admin/users' },
          { title: 'Stores', icon: 'BuildingStorefrontIcon', path: '/admin/stores' },
          { title: 'Delivery', icon: 'TruckIcon', path: '/admin/delivery' },
          { title: 'Reports', icon: 'ChartBarIcon', path: '/admin/reports' },
          { title: 'Settings', icon: 'CogIcon', path: '/admin/settings' },
        ];
      default:
        return [];
    }
  };

  return (
    <div className="h-screen flex overflow-hidden bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-white">
      {/* Sidebar */}
      <Sidebar 
        isOpen={isSidebarOpen} 
        menuItems={getSidebarItems()} 
        userType={userType}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader 
          userType={userType} 
          userName={user?.name || 'User'}
        />

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>

      {/* Notifications */}
      <div className="fixed bottom-4 right-4 z-50 space-y-2">
        {notifications.map((notification) => (
          <NotificationToast
            key={notification.id}
            notification={notification}
          />
        ))}
      </div>
    </div>
  );
};

DashboardLayout.propTypes = {
  userType: PropTypes.oneOf(['seller', 'delivery', 'admin']).isRequired,
};

export default DashboardLayout;