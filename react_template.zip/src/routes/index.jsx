import { createBrowserRouter } from 'react-router-dom';

// Layouts
import MainLayout from '../components/layouts/MainLayout';
import DashboardLayout from '../components/layouts/DashboardLayout';
import AuthLayout from '../components/layouts/AuthLayout';

// Public pages
import HomePage from '../pages/HomePage';
import ShopPage from '../pages/ShopPage';
import ProductPage from '../pages/ProductDetailPage';
import CartPage from '../pages/CartPage';
import CheckoutPage from '../pages/checkout/CheckoutPage';
import LoginPage from '../pages/auth/LoginPage';
import RegisterPage from '../pages/auth/RegisterPage';
import ForgotPasswordPage from '../pages/auth/ForgotPasswordPage';

// Placeholder for missing pages
// We'll need to create these files
import ContactPage from '../components/placeholders/PlaceholderPage';
import AboutPage from '../components/placeholders/PlaceholderPage';
import ProfilePage from '../components/placeholders/PlaceholderPage';
import OrdersPage from '../components/placeholders/PlaceholderPage';
import WishlistPage from '../components/placeholders/PlaceholderPage';

// Seller/Store pages - using placeholder
import SellerDashboard from '../components/placeholders/PlaceholderPage';
import SellerProducts from '../components/placeholders/PlaceholderPage';
import SellerOrders from '../components/placeholders/PlaceholderPage';
import SellerInventory from '../components/placeholders/PlaceholderPage';
import SellerReports from '../components/placeholders/PlaceholderPage';
import SellerSettings from '../components/placeholders/PlaceholderPage';

// Delivery pages - using placeholder
import DeliveryDashboard from '../components/placeholders/PlaceholderPage';
import DeliveryOrders from '../components/placeholders/PlaceholderPage';
import DeliveryTracking from '../components/placeholders/PlaceholderPage';
import DeliveryFinance from '../components/placeholders/PlaceholderPage';
import DeliverySettings from '../components/placeholders/PlaceholderPage';

// Admin pages - using placeholder
import AdminDashboard from '../components/placeholders/PlaceholderPage';
import AdminUsers from '../components/placeholders/PlaceholderPage';
import AdminStores from '../components/placeholders/PlaceholderPage';
import AdminDelivery from '../components/placeholders/PlaceholderPage';
import AdminSettings from '../components/placeholders/PlaceholderPage';
import AdminReports from '../components/placeholders/PlaceholderPage';

// Error pages - using placeholder
import NotFoundPage from '../components/placeholders/PlaceholderPage';

// Auth components
import ProtectedRoute from '../components/common/ProtectedRoute';

const router = createBrowserRouter([
  {
    path: '/',
    element: <MainLayout />,
    errorElement: <NotFoundPage />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'shop', element: <ShopPage /> },
      { path: 'product/:productId', element: <ProductPage /> },
      { path: 'cart', element: <CartPage /> },
      { path: 'checkout', element: <ProtectedRoute><CheckoutPage /></ProtectedRoute> },
      { path: 'contact', element: <ContactPage /> },
      { path: 'about', element: <AboutPage /> },
      { 
        path: 'profile',
        element: <ProtectedRoute roles={['customer']}><ProfilePage /></ProtectedRoute>
      },
      { 
        path: 'orders',
        element: <ProtectedRoute roles={['customer']}><OrdersPage /></ProtectedRoute>
      },
      { 
        path: 'wishlist',
        element: <ProtectedRoute roles={['customer']}><WishlistPage /></ProtectedRoute>
      },
    ],
  },
  {
    path: '/auth',
    element: <AuthLayout />,
    children: [
      { path: 'login', element: <LoginPage /> },
      { path: 'register', element: <RegisterPage /> },
      { path: 'forgot-password', element: <ForgotPasswordPage /> },
    ],
  },
  {
    path: '/seller',
    element: <ProtectedRoute roles={['seller']}><DashboardLayout userType="seller" /></ProtectedRoute>,
    children: [
      { index: true, element: <SellerDashboard /> },
      { path: 'products', element: <SellerProducts /> },
      { path: 'orders', element: <SellerOrders /> },
      { path: 'inventory', element: <SellerInventory /> },
      { path: 'reports', element: <SellerReports /> },
      { path: 'settings', element: <SellerSettings /> },
    ],
  },
  {
    path: '/delivery',
    element: <ProtectedRoute roles={['delivery']}><DashboardLayout userType="delivery" /></ProtectedRoute>,
    children: [
      { index: true, element: <DeliveryDashboard /> },
      { path: 'orders', element: <DeliveryOrders /> },
      { path: 'tracking', element: <DeliveryTracking /> },
      { path: 'finance', element: <DeliveryFinance /> },
      { path: 'settings', element: <DeliverySettings /> },
    ],
  },
  {
    path: '/admin',
    element: <ProtectedRoute roles={['admin']}><DashboardLayout userType="admin" /></ProtectedRoute>,
    children: [
      { index: true, element: <AdminDashboard /> },
      { path: 'users', element: <AdminUsers /> },
      { path: 'stores', element: <AdminStores /> },
      { path: 'delivery', element: <AdminDelivery /> },
      { path: 'reports', element: <AdminReports /> },
      { path: 'settings', element: <AdminSettings /> },
    ],
  },
]);

export default router;